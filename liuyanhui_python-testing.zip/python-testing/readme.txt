1. Must complete questions for pytest & selenium
2. design-test-case is additiona bonus question.

Send to us to review the quiz result when the candidate completes point 1. 